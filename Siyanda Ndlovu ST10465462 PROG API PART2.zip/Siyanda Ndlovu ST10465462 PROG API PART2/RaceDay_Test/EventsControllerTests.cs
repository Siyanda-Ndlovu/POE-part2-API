﻿using Xunit;
using System;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Data;
using RaceDayPOE_part2.Controllers;
using RaceDayPOE_part2.DTOs;
using RaceDayPOE_part2.Models;

namespace RaceDay_Test
{
    public class EventsControllerTests
    {

        private RaceDayDbContext CreateDatabase()
        {
            var options = new DbContextOptionsBuilder<RaceDayDbContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            return new RaceDayDbContext(options);
        }

        private CreateEventDto ValidEvent()
        {
            return new CreateEventDto
            {
                event_name = "Johannesburg Marathon",
                location = "Johannesburg",
                organiser_ID = 1,
                category_ID = 1
            };
        }

        // TEST 1: Get all events
        [Fact]
        public async Task GetEvents_ReturnsOk()
        {
            using var db = CreateDatabase();
            var controller = new EventsController(db);

            var result = await controller.GetEvents();

            Assert.IsType<OkObjectResult>(result);
        }

        // TEST 2: Event does not exist
        [Fact]
        public async Task GetEvent_NotFound_ReturnsNotFound()
        {
            using var db = CreateDatabase();
            var controller = new EventsController(db);

            var result = await controller.GetEvent(999);

            Assert.IsType<NotFoundObjectResult>(result);
        }

        // TEST 3: Missing event name
        [Fact]
        public async Task CreateEvent_MissingName_ReturnsBadRequest()
        {
            using var db = CreateDatabase();
            var controller = new EventsController(db);

            var dto = ValidEvent();
            dto.event_name = "";

            var result = await controller.CreateEvent(dto);

            Assert.IsType<BadRequestObjectResult>(result);
        }

        // TEST 4: Missing location
        [Fact]
        public async Task CreateEvent_MissingLocation_ReturnsBadRequest()
        {
            using var db = CreateDatabase();
            var controller = new EventsController(db);

            var dto = ValidEvent();
            dto.location = "";

            var result = await controller.CreateEvent(dto);

            Assert.IsType<BadRequestObjectResult>(result);
        }

        // TEST 5: Organiser does not exist
        [Fact]
        public async Task CreateEvent_InvalidOrganiser_ReturnsBadRequest()
        {
            using var db = CreateDatabase();
            var controller = new EventsController(db);

            var result = await controller.CreateEvent(ValidEvent());

            var badRequest = Assert.IsType<BadRequestObjectResult>(result);

            Assert.Equal("Organiser not found.", badRequest.Value);
        }

        // TEST 6: Category does not exist
        [Fact]
        public async Task CreateEvent_InvalidCategory_ReturnsBadRequest()
        {
            using var db = CreateDatabase();

            db.Organisers.Add(new Organiser
            {
                organiser_ID = 1,
                user_ID = 1
            });

            await db.SaveChangesAsync();

            var controller = new EventsController(db);

            var result = await controller.CreateEvent(ValidEvent());

            var badRequest = Assert.IsType<BadRequestObjectResult>(result);

            Assert.Equal("Category not found.", badRequest.Value);
        }

        // TEST 7: Update event that does not exist
        [Fact]
        public async Task UpdateEvent_NotFound_ReturnsNotFound()
        {
            using var db = CreateDatabase();
            var controller = new EventsController(db);

            var result = await controller.UpdateEvent(999, ValidEvent());

            Assert.IsType<NotFoundObjectResult>(result);
        }

        // TEST 8: Organiser-only POST attribute
        [Fact]
        public void CreateEvent_RequiresOrganiserRole()
        {
            var method = typeof(EventsController)
                .GetMethod(nameof(EventsController.CreateEvent));

            var attribute = method!
                .GetCustomAttributes(
                    typeof(Microsoft.AspNetCore.Authorization.AuthorizeAttribute),
                    false)
                .Cast<Microsoft.AspNetCore.Authorization.AuthorizeAttribute>()
                .FirstOrDefault();

            Assert.NotNull(attribute);
            Assert.Equal("Organiser", attribute.Roles);
        }

        // TEST 9: Organiser-only PUT attribute
        [Fact]
        public void UpdateEvent_RequiresOrganiserRole()
        {
            var method = typeof(EventsController)
                .GetMethod(nameof(EventsController.UpdateEvent));

            var attribute = method!
                .GetCustomAttributes(
                    typeof(Microsoft.AspNetCore.Authorization.AuthorizeAttribute),
                    false)
                .Cast<Microsoft.AspNetCore.Authorization.AuthorizeAttribute>()
                .FirstOrDefault();

            Assert.NotNull(attribute);
            Assert.Equal("Organiser", attribute.Roles);
        }

        // TEST 10: GET allows both roles
        [Fact]
        public void GetEvents_AllowsBothRoles()
        {
            var method = typeof(EventsController)
                .GetMethod(nameof(EventsController.GetEvents));

            var attribute = method!
                .GetCustomAttributes(
                    typeof(Microsoft.AspNetCore.Authorization.AuthorizeAttribute),
                    false)
                .Cast<Microsoft.AspNetCore.Authorization.AuthorizeAttribute>()
                .FirstOrDefault();

            Assert.NotNull(attribute);
            Assert.Contains("Participant", attribute.Roles!);
            Assert.Contains("Organiser", attribute.Roles!);
        }

        // TEST 11: Update missing name
        [Fact]
        public async Task UpdateEvent_MissingName_ReturnsBadRequest()
        {
            using var db = CreateDatabase();

            db.Events.Add(new Event
            {
                event_ID = 1,
                event_name = "Old Event",
                location = "Pretoria",
                organiser_ID = 1,
                category_ID = 1
            });

            await db.SaveChangesAsync();

            var dto = ValidEvent();
            dto.event_name = "";

            var controller = new EventsController(db);
            var result = await controller.UpdateEvent(1, dto);

            Assert.IsType<BadRequestObjectResult>(result);
        }

        // TEST 12: Update missing location
        [Fact]
        public async Task UpdateEvent_MissingLocation_ReturnsBadRequest()
        {
            using var db = CreateDatabase();

            db.Events.Add(new Event
            {
                event_ID = 1,
                event_name = "Old Event",
                location = "Pretoria",
                organiser_ID = 1,
                category_ID = 1
            });

            await db.SaveChangesAsync();

            var dto = ValidEvent();
            dto.location = "";

            var controller = new EventsController(db);
            var result = await controller.UpdateEvent(1, dto);

            Assert.IsType<BadRequestObjectResult>(result);
        }

    }
}
