CREATE DATABASE RaceDay;
USE RaceDay;

CREATE TABLE Users(
user_ID INT IDENTITY PRIMARY KEY,
name VARCHAR(20),
phoneNumber INT,
email VARCHAR(30),
password VARCHAR(30)
);

--Creating table organiser
CREATE TABLE Organiser(
    organiser_ID INT IDENTITY(1,1) PRIMARY KEY,
    user_ID INT NOT NULL,
    FOREIGN KEY (user_ID) REFERENCES Users(user_ID)
);

--Creating table category
CREATE TABLE Category(
category_ID INT IDENTITY(1,1) PRIMARY KEY,
categoryName VARCHAR(50) NOT NULL,
distance DECIMAL(10,2),
StartTime TIME,
event_ID INT NULL,
organiser_ID INT NULL,
FOREIGN KEY (organiser_ID) REFERENCES Organiser(organiser_ID)
);

--Creating table event
CREATE TABLE Event(
event_ID INT IDENTITY(1,1) PRIMARY KEY,
event_name VARCHAR(100) NOT NULL,
location VARCHAR(100) NOT NULL,
organiser_ID INT NOT NULL,
category_ID INT NOT NULL,
FOREIGN KEY (organiser_ID) REFERENCES Organiser(organiser_ID),
FOREIGN KEY (category_ID) REFERENCES Category(category_ID)
);

--Creating table Participant
CREATE TABLE Participant(
participant_ID INT IDENTITY(1,1) PRIMARY KEY,
event_ID INT NOT NULL,
user_ID INT NOT NULL,
FOREIGN KEY (event_ID) REFERENCES Event(event_ID),
FOREIGN KEY (user_ID) REFERENCES Users(user_ID)
);

--Creating table enrolment
CREATE TABLE Enrolment(
enrolmentID INT IDENTITY(1,1) PRIMARY KEY,
enrolmentDate DATE NOT NULL,
event_ID INT NOT NULL,
participantID INT NOT NULL,
FOREIGN KEY (event_ID) REFERENCES Event(event_ID),
FOREIGN KEY (participantID) REFERENCES Participant(participant_ID)
);

-- Creating the Result table
CREATE TABLE Result(
result_ID INT IDENTITY(1,1) PRIMARY KEY,
position INT,
finishingTime TIME,
enrolment_ID INT NOT NULL,
FOREIGN KEY (enrolment_ID) REFERENCES Enrolment(enrolmentID)
);



-- Inserting users
INSERT INTO Users (name, phoneNumber, email, password)
VALUES
('Siyanda Ndlovu', '0712345678', 'siyanda@gmail.com', 'Pass123'),
('Thando Mkhize', '0723456789', 'thando@gmail.com', 'Pass456'),
('Lerato Dlamini', '0734567890', 'lerato@gmail.com', 'Pass789'),
('Musa Nkosi', '0745678901', 'musa@gmail.com', 'Pass321'),
('Kabelo Mokoena', '0756789012', 'kabelo@gmail.com', 'Pass654');

SELECT * FROM Users;


-- Inserting organisers
INSERT INTO Organiser (user_ID)
VALUES
(1),
(2),
(3);

SELECT * FROM Organiser;


-- Inserting participants
INSERT INTO Participant (event_ID, user_ID)
VALUES
(1, 4),
(1, 5),
(2, 1),
(2, 3),
(3, 2);

SELECT * FROM Participant;


-- Inserting events
INSERT INTO Event (event_name, location, organiser_ID, category_ID)
VALUES
('Cape Town 10 km Run', 'Cape Town, South Africa', 2, 2),
('Cape Town Half Marathon', 'Cape Town, South Africa', 3, 3),
('Cape Town Full Marathon', 'Cape Town, South Africa', 4, 4),
('Cape Town Cycling Challenge', 'Cape Town, South Africa', 5, 5);

SELECT * FROM Event;


-- Inserting categories
INSERT INTO Category (categoryName, distance, StartTime, event_ID, organiser_ID)
VALUES
('10 km Run', 10.00, '07:00:00', NULL, 2),
('Half Marathon', 21.10, '06:30:00', NULL, 2),
('Full Marathon', 42.20, '06:00:00', NULL, 2),
('Cycling', 40.00, '08:00:00', NULL, 2);

SELECT * FROM Category;


-- Inserting enrolments
INSERT INTO Enrolment
(enrolmentDate, event_ID, participantID)
VALUES
('2026-08-01', 1, 1),
('2026-08-02', 1, 2),
('2026-08-03', 2, 3),
('2026-08-04', 2, 4),
('2026-08-05', 3, 5);

SELECT * FROM Enrolment;

