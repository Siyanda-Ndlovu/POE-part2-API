﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Data;

namespace RaceDay.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DatabaseController : ControllerBase
    {
        private readonly RaceDayDbContext _context;

        public DatabaseController(RaceDayDbContext context)
        {
            _context = context;
        }


        [HttpGet("users-count")]
        public async Task<IActionResult> GetUsersCount()
        {
            int count = await _context.Users.CountAsync();

            return Ok(new
            {
                Message = "Users retrieved successfully.",
                TotalUsers = count
            });
        }


        [HttpGet("test")]
        public async Task<IActionResult> TestConnection()
        {
            try
            {
                await _context.Database.OpenConnectionAsync();

                await _context.Database.CloseConnectionAsync();

                return Ok("Successfully connected to the RaceDay database!");
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    Message = ex.Message,
                    Details = ex.InnerException?.Message
                });
            }
        }

    }
}
