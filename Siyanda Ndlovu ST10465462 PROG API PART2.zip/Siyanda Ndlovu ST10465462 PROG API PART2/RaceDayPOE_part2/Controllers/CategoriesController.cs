﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using RaceDay.Data;
using RaceDayPOE_part2.DTOs;
using RaceDayPOE_part2.Models;

namespace RaceDayPOE_part2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoriesController : ControllerBase
    {
        private readonly RaceDayDbContext _context;

        public CategoriesController(RaceDayDbContext context)
        {
            _context = context;
        }

        // GET: api/Categories
        [Authorize(Roles = "Participant,Organiser")]
        [HttpGet]
        public async Task<IActionResult> GetCategories()
        {
            var categories = await _context.Categories
                .ToListAsync();

            return Ok(categories);
        }

        // GET: api/Categories/2
        [Authorize(Roles = "Participant,Organiser")]
        [HttpGet("{id}")]
        public async Task<IActionResult> GetCategory(int id)
        {
            var category = await _context.Categories
                .FirstOrDefaultAsync(c => c.category_ID == id);

            if (category == null)
            {
                return NotFound("Category not found.");
            }

            return Ok(category);
        }

        // POST: api/Categories
        [Authorize(Roles = "Organiser")]
        [HttpPost]
        public async Task<IActionResult> CreateCategory(
            CreateCategoryDto dto)
        {
            if (string.IsNullOrWhiteSpace(dto.categoryName))
            {
                return BadRequest("Category name is required.");
            }

            if (dto.distance.HasValue && dto.distance.Value <= 0)
            {
                return BadRequest("Distance must be greater than zero.");
            }

            var userIdValue = User.FindFirst(
                ClaimTypes.NameIdentifier)?.Value;

            if (!int.TryParse(userIdValue, out int userId))
            {
                return Unauthorized("Invalid user identity.");
            }

            var organiser = await _context.Organisers
                .FirstOrDefaultAsync(o => o.user_ID == userId);

            if (organiser == null)
            {
                return Forbid();
            }

            var category = new Category
            {
                categoryName = dto.categoryName.Trim(),
                distance = dto.distance,
                StartTime = dto.StartTime,
                organiser_ID = organiser.organiser_ID
            };

            _context.Categories.Add(category);
            await _context.SaveChangesAsync();

            return CreatedAtAction(
                nameof(GetCategory),
                new { id = category.category_ID },
                category);
        }

        // PUT: api/Categories/2
        [Authorize(Roles = "Organiser")]
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateCategory(
            int id, CreateCategoryDto dto)
        {
            var category = await _context.Categories
                .FirstOrDefaultAsync(c => c.category_ID == id);

            if (category == null)
            {
                return NotFound("Category not found.");
            }

            if (string.IsNullOrWhiteSpace(dto.categoryName))
            {
                return BadRequest("Category name is required.");
            }

            if (dto.distance.HasValue && dto.distance.Value <= 0)
            {
                return BadRequest("Distance must be greater than zero.");
            }

            var userIdValue = User.FindFirst(
                ClaimTypes.NameIdentifier)?.Value;

            if (!int.TryParse(userIdValue, out int userId))
            {
                return Unauthorized("Invalid user identity.");
            }

            var organiser = await _context.Organisers
                .FirstOrDefaultAsync(o => o.user_ID == userId);

            if (organiser == null)
            {
                return Forbid();
            }

            if (category.organiser_ID != organiser.organiser_ID)
            {
                return Forbid();
            }

            category.categoryName = dto.categoryName.Trim();
            category.distance = dto.distance;
            category.StartTime = dto.StartTime;

            await _context.SaveChangesAsync();

            return Ok(new
            {
                Message = "Category updated successfully.",
                Category = category
            });
        }

        // DELETE: api/Categories/2
        [Authorize(Roles = "Organiser")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCategory(int id)
        {
            var category = await _context.Categories
                .FirstOrDefaultAsync(c => c.category_ID == id);

            if (category == null)
            {
                return NotFound("Category not found.");
            }

            var userIdValue = User.FindFirst(
                ClaimTypes.NameIdentifier)?.Value;

            if (!int.TryParse(userIdValue, out int userId))
            {
                return Unauthorized("Invalid user identity.");
            }

            var organiser = await _context.Organisers
                .FirstOrDefaultAsync(o => o.user_ID == userId);

            if (organiser == null)
            {
                return Forbid();
            }

            if (category.organiser_ID != organiser.organiser_ID)
            {
                return Forbid();
            }

            bool categoryInUse = await _context.Events
                .AnyAsync(e => e.category_ID == id);

            if (categoryInUse)
            {
                return Conflict(
                    "This category cannot be deleted because an event uses it.");
            }

            _context.Categories.Remove(category);
            await _context.SaveChangesAsync();

            return Ok("Category deleted successfully.");
        }
    }
}
