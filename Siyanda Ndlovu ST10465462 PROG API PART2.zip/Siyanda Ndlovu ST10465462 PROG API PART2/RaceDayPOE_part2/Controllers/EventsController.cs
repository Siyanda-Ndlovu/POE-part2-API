﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Authorization;
using RaceDayPOE_part2.DTOs;
using RaceDayPOE_part2.Models;

namespace RaceDayPOE_part2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EventsController : ControllerBase
    {

        private readonly RaceDayDbContext _context;

        public EventsController(RaceDayDbContext context)
        {
            _context = context;
        }

        // GET: api/Events
        [Authorize(Roles = "Participant,Organiser")]
        [HttpGet]
        public async Task<IActionResult> GetEvents()
        {
            var events = await _context.Events
                .Select(e => new
                {
                    e.event_ID,
                    e.event_name,
                    e.location,
                    e.organiser_ID,
                    e.category_ID
                })
                .ToListAsync();

            return Ok(events);
        }

        // GET: api/Events/1
        [Authorize(Roles = "Participant,Organiser")]
        [HttpGet("{id}")]
        public async Task<IActionResult> GetEvent(int id)
        {
            var eventItem = await _context.Events
                .Where(e => e.event_ID == id)
                .Select(e => new
                {
                    e.event_ID,
                    e.event_name,
                    e.location,
                    e.organiser_ID,
                    e.category_ID
                })
                .FirstOrDefaultAsync();

            if (eventItem == null)
            {
                return NotFound("Event not found.");
            }

            return Ok(eventItem);
        }


        // POST: api/Events
        [Authorize(Roles = "Organiser")]
        [HttpPost]
        public async Task<IActionResult> CreateEvent(CreateEventDto dto)
        {
            if (string.IsNullOrWhiteSpace(dto.event_name) ||
                string.IsNullOrWhiteSpace(dto.location))
            {
                return BadRequest("Event name and location are required.");
            }

            var organiser = await _context.Organisers
                .FirstOrDefaultAsync(o => o.organiser_ID == dto.organiser_ID);

            if (organiser == null)
            {
                return BadRequest("Organiser not found.");
            }

            var category = await _context.Categories
                .FirstOrDefaultAsync(c => c.category_ID == dto.category_ID);

            if (category == null)
            {
                return BadRequest("Category not found.");
            }

            var eventItem = new Event
            {
                event_name = dto.event_name.Trim(),
                location = dto.location.Trim(),
                organiser_ID = dto.organiser_ID,
                category_ID = dto.category_ID
            };

            _context.Events.Add(eventItem);
            await _context.SaveChangesAsync();

            return CreatedAtAction(
                nameof(GetEvent),
                new { id = eventItem.event_ID },
                eventItem);
        }


        // PUT: api/Events/1
        [Authorize(Roles = "Organiser")]
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateEvent(
            int id, CreateEventDto dto)
        {
            var eventItem = await _context.Events
                .FirstOrDefaultAsync(e => e.event_ID == id);

            if (eventItem == null)
            {
                return NotFound("Event not found.");
            }

            if (string.IsNullOrWhiteSpace(dto.event_name) ||
                string.IsNullOrWhiteSpace(dto.location))
            {
                return BadRequest(
                    "Event name and location are required.");
            }

            var organiser = await _context.Organisers
                .FirstOrDefaultAsync(
                    o => o.organiser_ID == dto.organiser_ID);

            if (organiser == null)
            {
                return BadRequest("Organiser not found.");
            }

            var category = await _context.Categories
                .FirstOrDefaultAsync(
                    c => c.category_ID == dto.category_ID);

            if (category == null)
            {
                return BadRequest("Category not found.");
            }

            eventItem.event_name = dto.event_name.Trim();
            eventItem.location = dto.location.Trim();
            eventItem.organiser_ID = dto.organiser_ID;
            eventItem.category_ID = dto.category_ID;

            await _context.SaveChangesAsync();

            return Ok(new
            {
                Message = "Event updated successfully.",
                Event = eventItem
            });
        }


    }
}
