﻿
using RaceDayPOE_part2.DTOs;
using RaceDayPOE_part2.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using System.Security.Claims;
using RaceDay.Data;

namespace RaceDayPOE_part2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class EnrolmentsController : ControllerBase
    {
        private readonly RaceDayDbContext _context;

        public EnrolmentsController(RaceDayDbContext context)
        {
            _context = context;
        }

        // GET: api/Enrolments
        // Participants see their own enrolments.
        // Organisers see enrolments for their own events.
        [HttpGet]
        [Authorize(Roles = "Participant,Organiser")]
        public async Task<IActionResult> GetEnrolments()
        {
            var userIdClaim = User.FindFirstValue(
                ClaimTypes.NameIdentifier);

            if (!int.TryParse(userIdClaim, out int userId))
            {
                return Unauthorized("Invalid user identity.");
            }

            var query = _context.Enrolments.AsQueryable();

            if (User.IsInRole("Participant"))
            {
                var participantIds = await _context.Participants
                    .Where(p => p.user_ID == userId)
                    .Select(p => p.participant_ID)
                    .ToListAsync();

                query = query.Where(e =>
                    participantIds.Contains(e.participantID));
            }
            else if (User.IsInRole("Organiser"))
            {
                var organiser = await _context.Organisers
                    .FirstOrDefaultAsync(o => o.user_ID == userId);

                if (organiser == null)
                {
                    return NotFound("Organiser profile not found.");
                }

                var eventIds = await _context.Events
                    .Where(e => e.organiser_ID == organiser.organiser_ID)
                    .Select(e => e.event_ID)
                    .ToListAsync();

                query = query.Where(e =>
                    eventIds.Contains(e.event_ID));
            }

            var enrolments = await query
                .Select(e => new
                {
                    e.enrolmentID,
                    e.enrolmentDate,
                    e.event_ID,
                    e.participantID
                })
                .ToListAsync();

            return Ok(enrolments);
        }

        // POST: api/Enrolments
        // Only participants can enrol.
        [HttpPost]
        [Authorize(Roles = "Participant")]
        public async Task<IActionResult> CreateEnrolment(
            EnrolmentDto dto)
        {
            var userIdClaim = User.FindFirstValue(
                ClaimTypes.NameIdentifier);

            if (!int.TryParse(userIdClaim, out int userId))
            {
                return Unauthorized("Invalid user identity.");
            }

            // Check that the event exists.
            var selectedEvent = await _context.Events
                .FirstOrDefaultAsync(e => e.event_ID == dto.event_ID);

            if (selectedEvent == null)
            {
                return NotFound("The selected event does not exist.");
            }

            // Find the logged-in user's participant profile
            // for this event.
            var participant = await _context.Participants
                .FirstOrDefaultAsync(p =>
                    p.user_ID == userId &&
                    p.event_ID == dto.event_ID);

            if (participant == null)
            {
                return BadRequest(
                    "Your participant profile is not registered for this event.");
            }

            // Prevent duplicate enrolments.
            var alreadyEnrolled = await _context.Enrolments
                .AnyAsync(e =>
                    e.event_ID == dto.event_ID &&
                    e.participantID == participant.participant_ID);

            if (alreadyEnrolled)
            {
                return Conflict(
                    "You are already enrolled in this event.");
            }

            var enrolment = new Enrolment
            {
                enrolmentDate = DateOnly.FromDateTime(DateTime.Today),
                event_ID = dto.event_ID,
                participantID = participant.participant_ID
            };

            _context.Enrolments.Add(enrolment);
            await _context.SaveChangesAsync();

            return Created(
                $"api/Enrolments",
                new
                {
                    enrolment.enrolmentID,
                    enrolment.enrolmentDate,
                    enrolment.event_ID,
                    enrolment.participantID
                });
        }
    }
}
