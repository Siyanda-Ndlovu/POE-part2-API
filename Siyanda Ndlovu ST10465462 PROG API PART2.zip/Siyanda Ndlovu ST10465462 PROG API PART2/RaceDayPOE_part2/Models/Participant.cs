﻿namespace RaceDayPOE_part2.Models
{
    public class Participant
    {
        public int participant_ID { get; set; }
        public int event_ID { get; set; }
        public int user_ID { get; set; }
    }
}
