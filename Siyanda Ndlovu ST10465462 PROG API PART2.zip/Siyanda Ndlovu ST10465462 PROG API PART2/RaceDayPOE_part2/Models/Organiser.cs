﻿namespace RaceDayPOE_part2.Models
{
    public class Organiser
    {
        public int organiser_ID { get; set; }
        public int user_ID { get; set; }
    }
}
