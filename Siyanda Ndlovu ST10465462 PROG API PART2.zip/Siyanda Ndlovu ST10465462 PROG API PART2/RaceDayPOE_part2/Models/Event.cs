﻿namespace RaceDayPOE_part2.Models
{
    public class Event
    {
        public int event_ID { get; set; }
        public string? event_name { get; set; }
        public string? location { get; set; }
        public int organiser_ID { get; set; }
        public int category_ID { get; set; }
    }
}
