﻿namespace RaceDayPOE_part2.DTOs
{
    public class CreateEventDto
    {

        public string event_name { get; set; } = string.Empty;
        public string location { get; set; } = string.Empty;
        public int organiser_ID { get; set; }
        public int category_ID { get; set; }

    }
}
