﻿namespace RaceDayPOE_part2.DTOs
{
    public class CreateCategoryDto
    {

        public string categoryName { get; set; } = string.Empty;
        public decimal? distance { get; set; }
        public TimeOnly? StartTime { get; set; }

    }
}
